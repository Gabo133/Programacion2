/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programacion2;

import java.util.Scanner;




/**
 *
 * @author Estudiante
 */



public class Programacion2 {
    
    /**
     * @param args the command line arguments
     */
    public static int mostrar(){
        int numero = 2;
        System.out.println("funcion inicio");
        return numero*2;
    } 
    public static void main(String[] args) {
        // TODO code application logic here
        
        String nombre;
        int numero;
        Double decimal,decimal2;
        boolean verdadero,falso;
        char caracter;
        
        nombre = "hola";
        numero = 12;
        decimal = 2.2;
        verdadero = true;
        caracter = 'b';
        // System.out.println(nombre);
        
        if (numero == 2) {
            System.out.println("Es un 2");
        }else{
            System.out.println("No es un 2");
        }
        switch(nombre){
            case "hola":
                System.out.println("es a");
            case "nombre":
                System.out.println("es b");
        }
        while(numero < 10){
            System.out.println("El numero es" + numero);
            numero=numero + 1;
        }
        for (int i = 0; i < 10;i++){
            System.out.println(2* i);
        }
        
        int numero2 = mostrar();
        System.out.println(numero2);
       
        System.out.println(nombre.length());
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese un numero: ");
        numero = entrada.nextInt();
        System.out.println("El numero es: "+numero);
        
    }
    
}
