/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication9;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Estudiante
 */
public class JavaApplication9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int []arreglo = {1,2,3,4};
        int arreglo2 [] = new int [3];
        
        int matriz [] [] = new int [3][3];
        int [][]matriz2 ={{1,2,3},{1,2,3}};
        
        System.out.println(arreglo[0]);
        System.out.println(arreglo[1]);
        System.out.println(arreglo[2]);
        
        arreglo2[0] = 1;
        arreglo2[1] = 2;
        arreglo2[2] = 3;
        
        System.out.println(arreglo2[0]);
        
        matriz2[0][0] = 2;
        matriz2[0][1] = 2;
        
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println(arreglo[i]);
        }
        
        for (int i = 0; i < matriz2.length; i++) {
            for (int j = 0; j < matriz2[i].length; j++) {
                System.out.println(matriz2[i][j]);
            }
        }
        int [][]matriz3 = {{1,2},{2,1}};
        
        List<Integer> nota = new ArrayList<>();
        
        nota.add(12);
        Numero num = new Numero(4);
        System.out.println(num.sumar(3,4));
        num.sumar();
        num.sumar(10);
        System.out.println(num.valor);
    }
    
}
