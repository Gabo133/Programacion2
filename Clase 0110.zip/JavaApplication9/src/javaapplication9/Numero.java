/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication9;

/**
 *
 * @author Estudiante
 */
public class Numero {
    int valor;
    public Numero(int numero){
        this.valor = numero;
    }
    void sumar(int num){
        this.valor = this.valor + num;
    }
    int sumar(int num, int b){
        this.valor = this.valor + num + b;
        return this.valor;
    }
    void sumar(){
        System.out.println("Estoy sumando"); 
    }
}
