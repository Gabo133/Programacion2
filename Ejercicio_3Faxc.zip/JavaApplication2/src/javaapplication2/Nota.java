/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Gabriel
 */
public class Nota {
    String titulo;
    String subtitulo;
    String descripcion;
    public Nota(String _titulo, String _subtitulo, String _descripcion){
        titulo = _titulo;
        subtitulo = _subtitulo;
        descripcion = _descripcion;
    }

    String get_titulo() {
        return this.titulo;
    }

    String get_subtitulo() {
        return this.subtitulo;
    }

    String get_descripcion() {
        return this.descripcion;
    }

    void set_titulo(String newtitulo) {
        this.titulo = newtitulo;
    }

    void set_subtitulo(String newsubtitulo) {
        this.subtitulo = newsubtitulo;
    }

    void set_descripcion(String newdescripcion) {
        this.descripcion = newdescripcion;
    }
    
}
