/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author Gabriel
 */
class Contacto {
    String nombre;
    String numero;
    String direccion;
    
    public Contacto(String _nombre, String _numero, String _direccion){
        nombre = _nombre;
        numero = _numero;
        direccion = _direccion;
    }

    String get_nombre() {
        return this.nombre;
    }

    String get_numero() {
        return this.numero;
    }

    String get_direccion() {
        return this.direccion;
    }
    
}
