/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class JavaApplication2 {

    public static void menu_principal(List<Nota> notas, List<Contacto> contactos){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Eliga una opcion");
        System.out.println("1) Abrir mi Block de notas");
        System.out.println("2) Abrir mi agenda de Contactos");
        System.out.println("3) Salir");
        int opcion_principal = entrada.nextInt();

        switch (opcion_principal){
            case 1:
                abrir_notas(notas, contactos);
            case 2:
                abrir_contactos(notas, contactos);
            case 3:
                break;
        }
    }
    public static void main(String[] args) {
        List<Nota> notas = new ArrayList<>();
        List<Contacto> contactos = new ArrayList<>();
        menu_principal(notas, contactos);
    }

    static private void saludar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static private void usar_calculadora() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static private void abrir_notas(List<Nota> notas, List<Contacto> contactos) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("1) Añadir nota");
        System.out.println("2) Ver notas");
        System.out.println("3) Modificar Notas");
        System.out.println("4) Salir ");
        int opcion_menu = entrada.nextInt();
        switch (opcion_menu){
            case 1:
                notas = Anadir_nota(notas);
                menu_principal(notas, contactos);
            case 2:
                Ver_notas(notas);
                menu_principal(notas, contactos);
            case 3:
                notas = Modificar_notas(notas);
                menu_principal(notas, contactos);
            case 4:
                menu_principal(notas, contactos);
        }
    }

    static private void abrir_contactos(List<Nota> notas, List<Contacto> contactos) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("1) Añadir Contacto");
        System.out.println("2) Ver Contactos");
        System.out.println("3) Salir ");
        int opcion_menu = entrada.nextInt();
        switch (opcion_menu){
            case 1:
                contactos = Anadir_contacto(contactos);
                menu_principal(notas, contactos);
            case 2:
                Ver_contactos(contactos);
                menu_principal(notas, contactos);
            case 3:
                menu_principal(notas, contactos);
        }
    }

    static private List Anadir_nota(List<Nota> notas) {
        Scanner entrada_string = new Scanner(System.in);
        
        System.out.println("Crear nueva nota");
        System.out.println("Agrege el titulo de la nota: ");
        String titulo = entrada_string.nextLine();
        System.out.println("Agrege el subtitulo de la nota");
        String subtitulo = entrada_string.nextLine();
        System.out.println("Agrege la descripcion de la nota");
        String descripcion = entrada_string.nextLine();
        
        Nota nueva_nota = new Nota(titulo,subtitulo,descripcion);
        
        notas.add(nueva_nota);
        return notas;
    }

    static private void Ver_notas(List<Nota> notas) {
        for (int i = 0; i < notas.size(); i++) {
            System.out.println("Nota numero 1: " + i);
            System.out.println("Titulo: " + notas.get(i).get_titulo());
            System.out.println("SubTitulo: " + notas.get(i).get_subtitulo());
            System.out.println("Descripcion: " + notas.get(i).get_descripcion());
        }
    }

    static private List Modificar_notas(List<Nota> notas) {
        for (int i = 0; i < notas.size(); i++) {
            System.out.println("Nota numero 1: " + i);
            System.out.println("Titulo: " + notas.get(i).get_titulo());
        }
        System.out.println("Que nota decsea modificar: ");
        Scanner entrada = new Scanner(System.in);
        int opcion_modificar = entrada.nextInt();
        Scanner entrada_string = new Scanner(System.in);
        
        System.out.println("Nota con titulo: " + notas.get(opcion_modificar).get_titulo());
        System.out.println("Ingrese el nuevo titulo: ");
        String titulo = entrada_string.nextLine();
        System.out.println("Ingrese el nuevo subtitulo: ");
        String subtitulo = entrada_string.nextLine();
        System.out.println("Ingrese la nueva descripcion: ");
        String descripcion = entrada_string.nextLine();
        
        Nota nota_modificar = notas.get(opcion_modificar);
        nota_modificar.set_titulo(titulo);
        nota_modificar.set_subtitulo(subtitulo);
        nota_modificar.set_descripcion(descripcion);
        
        notas.set(opcion_modificar, nota_modificar);
        
        return notas;
    }

    private static List<Contacto> Anadir_contacto(List<Contacto> contactos) {
        Scanner entrada_string = new Scanner(System.in);
        
        System.out.println("Crear nuevo Contacto");
        System.out.println("Agrege el Nombre: ");
        String nombre = entrada_string.nextLine();
        System.out.println("Agrege el numero de telefono");
        String telefono = entrada_string.nextLine();
        System.out.println("Agrege la direccion");
        String direccion = entrada_string.nextLine();
        
        Contacto nuevo_contacto = new Contacto(nombre,telefono,direccion);
        
        contactos.add(nuevo_contacto);
        return contactos;
    }

    private static void Ver_contactos(List<Contacto> contactos) {
        for (int i = 0; i < contactos.size(); i++) {
            System.out.println("Contacto numero : " + i);
            System.out.println("Nombre: " + contactos.get(i).get_nombre());
            System.out.println("Numero: " + contactos.get(i).get_numero());
            System.out.println("Direccion: " + contactos.get(i).get_direccion());
        }
    }
    
}
