/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;


public class Contacto {
    String Nombre;
    String Direccion;
    int Edad;
    String Correo;
    boolean Favorito;
    
    public Contacto(String _Nombre, String _Direccion, int _Edad, String _Correo,boolean _Favorito){
        this.Nombre = _Nombre;
        this.Direccion = _Direccion;
        this.Edad = _Edad;
        this.Correo = _Correo;
        this.Favorito = _Favorito;
    }
    
}
