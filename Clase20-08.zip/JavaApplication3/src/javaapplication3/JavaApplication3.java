/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class JavaApplication3 {

    public static Contacto Anadir(){
        Scanner entrada = new Scanner(System.in);
        
        
        
        String Nombre;
        String Direccion;
        int Edad;
        String Correo;
        boolean Favorito;
        System.out.print("Ingrese nombre: ");
        Nombre = entrada.next();
        
        System.out.print("Ingrese Direccion: ");
        Direccion = entrada.next();
        
        System.out.print("Ingrese Edad: ");
        Edad = entrada.nextInt();
        
        System.out.print("Ingrese Correo: ");
        Correo = entrada.next();
        
        System.out.print("Ingrese Favorito: ");
        int Fav = entrada.nextInt();
        
        if(Fav == 1) {
            Favorito = true;
        }else{
            Favorito = false;
        }
        Contacto contc = new Contacto(Nombre,Direccion,Edad,Correo,Favorito);
        return contc;
    }
    public static void main(String[] args) {
        List<Contacto> lista;
        lista = new ArrayList<>();
        
        Scanner entrada = new Scanner(System.in);
        while(true){
            System.out.println("Opciones");
            System.out.println("1) Anadir Contacto");
            System.out.println("2) Ver contactos");
            System.out.println("3) Buscar Contacto");
            System.out.println("4) Editar Contacto");
            System.out.print("Seleccione una opcion: ");
            int opcion = entrada.nextInt();
            switch(opcion){
                case 1:
                    lista.add(Anadir());
                case 2:
                    for (int i = 0; i < lista.size(); i++) {
                        System.out.println((lista.get(i)).Nombre);
                    }
                    

            }
        }
    }
    
}
