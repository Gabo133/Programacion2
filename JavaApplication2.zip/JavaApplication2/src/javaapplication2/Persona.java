/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

public class Persona {
    String rut;
    String Nombre;
    int Edad;
    
    public Persona(String _rut,String _Nombre,int _Edad)
    {
        this.rut = _rut;
        this.Nombre = _Nombre;
        this.Edad = _Edad;
    }
    public void cumpleanno(){
        int numero;
        this.Edad = this.Edad + 1;
    }
    public void saludar(){
        System.out.println("hola mi nombre es" + this.Nombre);
    }
}
