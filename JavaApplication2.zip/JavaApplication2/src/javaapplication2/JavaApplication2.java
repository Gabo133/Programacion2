/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;




public class JavaApplication2 {

   
    
    public static void main(String[] args) {
        int numero = 8;
        String palabra;
        Double decimal;
        char caracter;
        boolean verdadero;
        List<String> lista;
        lista = new ArrayList<>();
        
        lista.add("hola");
        lista.add("chao");
        
        System.out.println(lista);
        
        for (int i = 0; i < lista.size(); ++i) 
        {
            System.out.println(lista.get(i));
        }
        
        while(numero < 10)
        {
            numero++;
            System.out.println(numero);
            
        }
        Hashtable<String,String> diccionario = new Hashtable<String,String>();
        diccionario.put("hola", "Saludo");
        diccionario.put("chao", "Saludo");
        
        System.out.println(diccionario.get("hola"));
        
        Persona persona1 = new Persona("20.123.312-1","Juan",18);
        Persona persona2 = new Persona("20.123.312-1","Juan",18);
        System.out.println(persona1.Edad);
        persona1.cumpleanno();
        System.out.println(persona1.Edad);
        
        Scanner entrada = new Scanner(System.in);
        int variable;
        String variable2,variable3;
        Persona personaJ;
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingrese la edad: ");
            variable = entrada.nextInt();
            System.out.println("Ingrese el Nombre: ");
            variable2 = entrada.next();
            System.out.println("Ingrese el rut: ");
            variable3 = entrada.next();
            personaJ = new Persona(variable2,variable3,variable);
        }
    }
    
}
